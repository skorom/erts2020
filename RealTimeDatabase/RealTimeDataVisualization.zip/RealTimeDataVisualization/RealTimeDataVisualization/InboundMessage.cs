﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RealTimeDataVisualization
{
    class InboundMessage
    {
        public string humidity { get; set; }

        public string temp { get; set; }
    }
}
